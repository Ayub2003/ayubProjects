class Calculator {
  constructor(idElement) {
    this.myStr = "";
    this.numbers = document.createElement("h1");
    document.getElementById(idElement).appendChild(this.numbers);
  }

  addSymbol = (symbol) => {
    this.myStr += symbol;
    this.numbers.textContent = this.myStr;
    console.log(this.myStr);

    return this.myStr;
  };

  showResult = () => {
    const operators = ["+", "-", "/", "*"];
    try {
      if (this.myStr != "") {
        for (let i = 0; i < operators.length; i++) {
          if (this.myStr.slice(-1) == operators[i]) {
            this.myStr = this.myStr.slice(0, -1);
            this.numbers.textContent = this.myStr;
          }
        }

        this.myStr = this.myStr + "=" + eval(this.myStr);
        this.numbers.textContent = this.myStr;
        console.log(this.myStr);
      } else {
        console.log("Вы не ввели выражение");
      }
      this.numbers.textContent = this.myStr;
      this.myStr = "";
    } catch (err) {
      this.myStr = "";
      this.numbers.textContent = "Что-то введено неверно";
      console.log("Что-то введено неверно");
    }
  };

  clear = () => {
    this.myStr = "";
    this.numbers.textContent = "Строка очищена";
    setTimeout(() => {
      this.numbers.textContent = this.myStr;
    }, 600);
    console.log("Строка очищена");
  };

  deleteOne = () => {
    this.myStr = this.myStr.slice(0, -1);
    this.numbers.textContent = this.myStr;
    console.log(this.myStr);
  };

  giveRespect = () => {
    this.numbers.textContent = "респ";
    console.log("Респект тебе");
  };
}

const Calc = new Calculator("output");
