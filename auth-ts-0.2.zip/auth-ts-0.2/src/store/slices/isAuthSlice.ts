import { createSlice } from "@reduxjs/toolkit";

const isAuthSlice = createSlice({
  name: "auth",
  initialState: { isAuth: false },
  reducers: {
    setTrueAuth(state) {
      state.isAuth = true;
    },
    setFalseAuth(state) {
      state.isAuth = false;
    },
  },
});

export const { setTrueAuth, setFalseAuth } = isAuthSlice.actions;
export default isAuthSlice.reducer;
