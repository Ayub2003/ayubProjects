import { createSlice } from "@reduxjs/toolkit";

export const initialState = {
  FIO: "",
  login: "",
  email: "",
  sex: "",
  birthday: "",
  password: "",
};

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    setUser(state, action) {
      state.FIO = action.payload.FIO;
      state.email = action.payload.email;
      state.login = action.payload.login;
      state.birthday = action.payload.birthday;
      state.sex = action.payload.sex;
      state.password = action.payload.passwor;
    },
    removeUser(state) {
      state.FIO = "";
      state.email = "";
      state.login = "";
      state.birthday = "";
      state.sex = "";
      state.password = "";
    },
  },
});

export const { setUser, removeUser } = userSlice.actions;
export default userSlice.reducer;
