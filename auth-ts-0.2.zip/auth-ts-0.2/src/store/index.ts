import { configureStore } from "@reduxjs/toolkit";
import userReducer from "./slices/userSlice";
import isAuthReducer from "./slices/isAuthSlice";

export const store = configureStore({
  reducer: {
    user: userReducer,
    auth: isAuthReducer,
  },
});
