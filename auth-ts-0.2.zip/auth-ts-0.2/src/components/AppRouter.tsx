import React from "react";
import { Route, Routes, redirect } from "react-router-dom";
import { Navigate } from "react-router-dom";
import { privateRoutes, publicRoutes } from "../routes";
import Navbar from "./Navbar";
import { useSelector } from "react-redux";

const AppRouter = () => {
  const auth = useSelector((state: any) => state.auth);
  return auth.isAuth === false ? (
    <Routes>
      {publicRoutes.map(({ path, Component }) => (
        <Route path={path} element={<Component />} />
      ))}
      <Route path="*" element={<Navigate to="/login" />} />
    </Routes>
  ) : (
    <>
      <Routes>
        {privateRoutes.map(({ path, Component }) => (
          <Route path={path} element={<Component />} />
        ))}
      </Routes>
      <Navbar />
    </>
  );
};

export default AppRouter;
