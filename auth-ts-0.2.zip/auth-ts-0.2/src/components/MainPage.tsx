import { useSpring, animated } from "@react-spring/web";

export const MainPage = () => {
  const [props, api] = useSpring(
    () => ({
      from: { opacity: 0 },
      to: { opacity: 1 },
    }),
    []
  );
  return (
    <animated.div
      style={{
        ...props,
        display: "flex",
        justifyContent: "center",
        maxHeight: "500px",
        alignItems: "center",
        textAlign: "center",
      }}
    >
      <h1>
        <img
          style={{ width: "90%", borderRadius: "15px", margin: "5px" }}
          src="https://www.kino-teatr.ru/news/4168/48290.jpg"
        />
        Main
      </h1>
    </animated.div>
  );
};
