import { useSpring, animated } from "@react-spring/web";
import "./ArticlesPage.css";
import Slide from "./Slider";
import { slideData } from "../utils/data";
import { testsData } from "../utils/data";
import { BiSearch } from "react-icons/bi";

export const ArticlesPage = () => {
  const [props, api] = useSpring(
    () => ({
      from: { opacity: 0 },
      to: { opacity: 1 },
    }),
    []
  );
  return (
    <animated.div
      style={{
        ...props,
      }}
    >
      <div className="header-articles">
        <div className="search-block">
          <div className="search-icon">
            <BiSearch style={{ color: "black", fontSize: "170%" }} />
          </div>
          <input
            placeholder="Статьи, болезни, симптомы"
            className="search-string"
          />
        </div>
      </div>
      <Slide
        title={slideData.title}
        route={slideData.route}
        slides={slideData.slides}
      />
      <Slide
        title={testsData.title}
        route={testsData.route}
        slides={testsData.slides}
      />
    </animated.div>
  );
};
