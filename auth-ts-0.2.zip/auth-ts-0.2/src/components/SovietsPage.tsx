import { useSpring, animated } from "@react-spring/web";

export const SovietsPage = () => {
  const [props, api] = useSpring(
    () => ({
      from: { opacity: 0 },
      to: { opacity: 1 },
    }),
    []
  );
  return (
    <animated.div
      style={{
        ...props,
        display: "flex",
        justifyContent: "center",
        height: "700px",
        alignItems: "center",
      }}
    >
      <h1>Soviets</h1>
    </animated.div>
  );
};
