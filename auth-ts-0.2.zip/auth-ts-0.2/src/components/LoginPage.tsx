import { MAIN_ROUTE, SIGNIN_ROUTE } from "../utils/consts";
import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { SubmitHandler } from "react-hook-form/dist/types";
import { IFieldsLogin } from "../utils/interfaces";
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";
import { useDispatch } from "react-redux";
import { setUser } from "../store/slices/userSlice";
import { useSpring, animated } from "@react-spring/web";
import { setTrueAuth } from "../store/slices/isAuthSlice";

export const LoginPage = () => {
  const [props, api] = useSpring(
    () => ({
      from: { opacity: 0 },
      to: { opacity: 1 },
    }),
    []
  );

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IFieldsLogin>();
  //////////////////////////////////////////////
  const onSubmit: SubmitHandler<IFieldsLogin> = ({ email, password }) => {
    const auth = getAuth();
    signInWithEmailAndPassword(auth, email, password)
      .then(({ user }) => {
        dispatch(
          setUser({
            email: user.email,
          })
        );
        dispatch(setTrueAuth());
        navigate(MAIN_ROUTE);
      })
      .catch(console.error);
  };
  ////////////////////////////////////////////////
  return (
    <animated.div style={{ ...props }} className="form-container">
      <div className="reg-header">
        <p>Вход</p>
      </div>
      <div className="form-wrapper">
        <form onSubmit={handleSubmit(onSubmit)}>
          <input
            {...register("email", { required: true })}
            type="email"
            placeholder="Email"
          />
          {errors?.email && (
            <div style={{ color: "red" }}>login введен неверно</div>
          )}

          <input
            {...register("password", { required: true })}
            type="password"
            placeholder="Пароль"
          />
          {errors?.password && (
            <div style={{ color: "red" }}>пароль введен неверно</div>
          )}

          <div>
            <button className="form-btn">Войти</button>
          </div>
        </form>
        <div className="reg-already">
          <p>
            Не зарегестрированы?{" "}
            <Link to={SIGNIN_ROUTE} className="nav-btn">
              Регистрация
            </Link>
          </p>
        </div>
      </div>
    </animated.div>
  );
};
