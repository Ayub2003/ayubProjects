import { useSpring, animated } from "@react-spring/web";
import { useSelector } from "react-redux";

export const NotesPage = () => {
  const select = useSelector((state: any) => state.user);
  const [props, api] = useSpring(
    () => ({
      from: {
        opacity: 0,
        fontSize: "50%",
        backgroundColor: "white",
        color: "black",
        top: "0px",
        left: "50px",
      },
      to: {
        opacity: 1,
        fontSize: "100%",
        backgroundColor: "blue",
        color: "white",
        top: "400px",
        left: "20px",
      },
    }),
    []
  );

  return (
    <animated.div
      style={{
        ...props,
        position: "fixed",
        borderRadius: "50px",
        padding: "20px",
      }}
    >
      {select.email}
    </animated.div>
  );
};
