import { useSpring, animated } from "@react-spring/web";

export const TestsPage = () => {
  const [props, api] = useSpring(
    () => ({
      from: { opacity: 0 },
      to: { opacity: 1 },
    }),
    []
  );
  return (
    <animated.div
      style={{
        ...props,
        display: "flex",
        justifyContent: "center",
        height: "700px",
        alignItems: "center",
      }}
    >
      <h1>Tests</h1>
    </animated.div>
  );
};
