import { useState } from "react";
import { useForm } from "react-hook-form";
import { SubmitHandler } from "react-hook-form/dist/types";
import { IFieldsReg } from "../utils/interfaces";
import "./SigninPage.css";
import { Link, useNavigate } from "react-router-dom";
import { LOGIN_ROUTE, MAIN_ROUTE } from "../utils/consts";
import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";
import { useSpring, animated } from "@react-spring/web";
import { useDispatch } from "react-redux";
import { setUser } from "../store/slices/userSlice";
import { setTrueAuth } from "../store/slices/isAuthSlice";

export const SigninPage = () => {
  const [props, api] = useSpring(
    () => ({
      from: { opacity: 0 },
      to: { opacity: 1 },
    }),
    []
  );
  const dispatch = useDispatch();
  const [pass1, setPass1] = useState<string>();
  const [pass2, setPass2] = useState<string>();
  const navigate = useNavigate();
  const [errorMes, setErrorMes] = useState("");
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IFieldsReg>();
  //////////////////////////////////////
  const onSubmit: SubmitHandler<IFieldsReg> = async ({
    email,
    password,
    password2,
    FIO,
    login,
    birthday,
    sex,
  }) => {
    if (password === password2 && password.length > 5) {
      const auth = getAuth();
      createUserWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
          // Signed in
          const user = userCredential.user;
          console.log(user);
          dispatch(setUser(user));
          dispatch(setTrueAuth());
          navigate(MAIN_ROUTE);
        })
        .catch((error) => {
          const errorCode = error.code;
          const errorMessage = error.message;
          console.log(error.message);
          setErrorMes(error.message);
        });

      console.log(
        FIO +
          "\n" +
          birthday +
          "\n" +
          email +
          "\n" +
          login +
          "\n" +
          password +
          "\n" +
          password2 +
          "\n" +
          sex
      );
    } else {
    }
  };
  ///////////////////////////////////////
  return (
    <animated.div style={{ ...props }} className="form-container">
      <div className="reg-header">
        <p>Регистрация</p>
      </div>
      <div className="form-wrapper">
        <form onSubmit={handleSubmit(onSubmit)}>
          <input
            {...register("FIO", { required: true })}
            type="text"
            placeholder="Имя Фамилия Отчество"
          />

          {errors?.FIO && (
            <div style={{ color: "red" }}>Что-то введено неверно</div>
          )}

          <input
            {...register("email", { required: true })}
            type="email"
            placeholder="Email"
          />
          {errors?.email && (
            <div style={{ color: "red" }}>Email введен неверно</div>
          )}

          <input
            {...register("birthday", { required: true })}
            type="date"
            placeholder="Email"
          />
          {errors?.birthday && (
            <div style={{ color: "red" }}>дата введен неверно</div>
          )}

          <input
            {...register("login", { required: true })}
            type="text"
            placeholder="Логин"
          />
          {errors?.login && (
            <div style={{ color: "red" }}>login введен неверно</div>
          )}

          <input
            {...register("password", { required: true })}
            type="password"
            placeholder="Пароль"
            onChange={(e) => setPass1(e.target.value)}
          />
          {errors?.password && (
            <div style={{ color: "red" }}>пароль введен неверно</div>
          )}

          <input
            {...register("password2", { required: true })}
            type="password"
            placeholder="Повторите пароль"
            onChange={(e) => setPass2(e.target.value)}
          />
          {errors?.password2 && (
            <div style={{ color: "red" }}>пароль2 введен неверно</div>
          )}

          {pass1 !== pass2 && (
            <p style={{ color: "red" }}>Пароли не совпадают</p>
          )}
          <p style={{ color: "red" }}>{errorMes}</p>

          <div className="radio-inputs">
            <p>Пол:</p>
            <label>
              Мужчина
              <input
                {...register("sex")}
                type="radio"
                name="sex"
                value="male"
              ></input>
            </label>
            <label>
              Женщина
              <input
                {...register("sex")}
                type="radio"
                name="sex"
                value="female"
              ></input>
            </label>
          </div>
          <div>
            <button className="form-btn">Зарегестрироваться</button>
          </div>
        </form>
        <div className="reg-already">
          <p>
            Уже зарегестрированы?
            <Link to={LOGIN_ROUTE} className="nav-btn">
              Войти
            </Link>
          </p>
        </div>
      </div>
    </animated.div>
  );
};
