import "./Slide.css";
import { ISlides } from "../utils/interfaces";
import { MAIN_ROUTE } from "../utils/consts";
import { Link } from "react-router-dom";

const Slide = (props: ISlides) => {
  const { title, route, slides } = props;
  return (
    <div className="slides-container">
      <div className="slides-title">
        <h2>{title}</h2>
        <Link className="link-to-detailes" to={route}>
          Еще {">"}
        </Link>
      </div>
      <div className="slides-box">
        {slides.map((slide) => {
          return (
            <div className="slide-item">
              <div className="slide-content">
                <div className="slide-preview-img">
                  <img src={slide.imgUrl} alt="Изображение" />
                </div>
                <div className="slide-preview-text">{slide.previewText}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Slide;
