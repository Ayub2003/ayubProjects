import { LOGIN_ROUTE, SIGNIN_ROUTE } from "../utils/consts";
import { Link } from "react-router-dom";
import "./ProfilePage.css";
import { useSelector, useDispatch } from "react-redux";
import { setFalseAuth } from "../store/slices/isAuthSlice";
import { useSpring, animated } from "@react-spring/web";
import { FaRegUserCircle } from "react-icons/fa";
import { AiOutlineSetting } from "react-icons/ai";
import { initialState, setUser } from "../store/slices/userSlice";
import { getAuth, signOut } from "firebase/auth";

export const ProfilePage = () => {
  const auth = useSelector((state: any) => state.auth);
  const user = useSelector((state: any) => state.user);
  const dispatch = useDispatch();
  const [props, api] = useSpring(
    () => ({
      from: { opacity: 0 },
      to: { opacity: 1 },
    }),
    []
  );
  const quiteAccount = () => {
    const auth = getAuth();
    signOut(auth)
      .then(() => {
        dispatch(setFalseAuth());
        dispatch(setUser(initialState));
        // Sign-out successful.
      })
      .catch((error) => {
        console.log("Что-то пошло не так ", error.message);
        // An error happened.
      });
  };
  return (
    <animated.div className="container" style={{ ...props }}>
      <div className="header">
        <div className="profile-info">
          <FaRegUserCircle style={{ fontSize: "220%" }} />
        </div>
        <div className="is-auth">
          {auth.isAuth === true ? (
            <div className="is-auth-child">
              <p>Вы выполнили вход</p>
              <button className="action-btn" onClick={quiteAccount}>
                Выйти из аккаунта
              </button>
            </div>
          ) : (
            <div className="is-auth-child">
              <p>Вы не выполнили вход</p>
              <Link to={LOGIN_ROUTE}>
                <button className="action-btn">Войти</button>
              </Link>
              <Link to={SIGNIN_ROUTE}>
                <button className="action-btn">Зарегестрироваться</button>
              </Link>
            </div>
          )}
        </div>

        <div className="profile-settings">
          <AiOutlineSetting style={{ fontSize: "220%" }} />
        </div>
      </div>
      <div className="content-profile"></div>
    </animated.div>
  );
};
