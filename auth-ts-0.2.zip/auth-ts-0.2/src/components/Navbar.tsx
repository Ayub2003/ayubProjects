import { Link } from "react-router-dom";
import * as consts from "../utils/consts";
import { NAVBAR_PARAMS } from "../utils/consts";
import "./Navbar.css";

export const Navbar = () => {
  return (
    <div className="navbar">
      {NAVBAR_PARAMS.map(({ title, link, Icon }) => (
        <Link to={link} className="nav-btn">
          <Icon className="nav-icon" />
          <p>{title}</p>
        </Link>
      ))}
    </div>
  );
};

export default Navbar;
