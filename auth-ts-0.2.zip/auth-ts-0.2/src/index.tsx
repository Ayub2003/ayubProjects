import React, { createContext } from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { store } from "./store/index";

//firebase imports
import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";
import { getAuth } from "firebase/auth";

//react-router-dom
import { BrowserRouter } from "react-router-dom";

//redux
import { Provider } from "react-redux";

// Initialize Firebase
const app = initializeApp({
  apiKey: "AIzaSyDbUeZ8t78loT6-vdWr7buuUg6REnIZ0ZE",
  authDomain: "auth-project-d4c8f.firebaseapp.com",
  projectId: "auth-project-d4c8f",
  storageBucket: "auth-project-d4c8f.appspot.com",
  messagingSenderId: "79935290824",
  appId: "1:79935290824:web:ef504463a50ee3aab5d4fd",
  measurementId: "G-WD62B3QRBB",
  databaseURL: "https://DATABASE_NAME.firebaseio.com",
});

const database = getDatabase(app);
const auth = getAuth();

const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);
root.render(
  <BrowserRouter>
    <Provider store={store}>
      <App />
    </Provider>
  </BrowserRouter>
);
