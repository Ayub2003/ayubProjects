import { SOVIETS_ROUTE, TESTS_ROUTE } from "./consts";

export const slideData = {
  title: "Советы",
  route: SOVIETS_ROUTE,
  slides: [
    {
      previewText: "Красота и уродство",
      imgUrl:
        "https://upload.wikimedia.org/wikipedia/ru/a/a9/%D0%9E%D0%B1%D0%BB%D0%BE%D0%B6%D0%BA%D0%B0_%D0%9A%D1%80%D0%B0%D1%81%D0%BE%D1%82%D0%B0_%D0%B8_%D1%83%D1%80%D0%BE%D0%B4%D1%81%D1%82%D0%B2%D0%BE.jpg",
    },
    {
      previewText: "Горгород",
      imgUrl:
        "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/Cover_of_Gorgorod.jpg/800px-Cover_of_Gorgorod.jpg",
    },
    {
      previewText: "Mixxxtape II",
      imgUrl:
        "https://upload.wikimedia.org/wikipedia/ru/4/49/%D0%94%D0%BE%D0%BB%D0%B3%D0%B8%D0%B9_%D0%BF%D1%83%D1%82%D1%8C_%D0%B4%D0%BE%D0%BC%D0%BE%D0%B9.png",
    },
    {
      previewText: "Music to be murdered by",
      imgUrl:
        "https://upload.wikimedia.org/wikipedia/ru/1/1e/Music_To_Be_Murdered_By.jpg",
    },
  ],
};

export const testsData = {
  title: "Тесты",
  route: TESTS_ROUTE,
  slides: [
    {
      previewText: "Смутное время",
      imgUrl:
        "https://upload.wikimedia.org/wikipedia/ru/6/6b/%D0%A1%D0%BC%D1%83%D1%82%D0%BD%D0%BE%D0%B5_%D0%B2%D1%80%D0%B5%D0%BC%D1%8F_%28%D0%B0%D0%BB%D1%8C%D0%B1%D0%BE%D0%BC_Oxxxymiron%29.jpg",
    },
    {
      previewText: "Вечный жид",
      imgUrl: "https://upload.wikimedia.org/wikipedia/ru/c/cd/Vechny_zhid.jpg",
    },
    {
      previewText: "Лето",
      imgUrl:
        "https://cdnn21.img.ria.ru/images/152324/71/1523247120_0:219:1000:782_600x0_80_0_0_7f1fb2d38e964a8fae9baf4846a32402.jpg",
    },
    {
      previewText: "Music to be murdered by",
      imgUrl:
        "https://i.scdn.co/image/ab67616d0000b273b84b0516d901f95461bb5165",
    },
  ],
};
