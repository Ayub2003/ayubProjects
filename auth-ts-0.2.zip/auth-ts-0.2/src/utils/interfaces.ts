import { is } from "@react-spring/shared";

export interface IContext {
  auth: any;
}

export interface IFieldsReg {
  FIO: string;
  login: string;
  email: string;
  sex: string;
  birthday: string;
  password: string;
  password2: string;
}

export interface IFieldsLogin {
  email: string;
  password: string;
}

interface ISlide {
  previewText: string;
  imgUrl: string;
}

export interface ISlides {
  title: string;
  route: string;
  slides: Array<ISlide>;
}
