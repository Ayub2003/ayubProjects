import { CgHome } from "react-icons/cg";
import { BsCalendarWeek } from "react-icons/bs";
import { BiSearch } from "react-icons/bi";
import { RiArticleLine } from "react-icons/ri";
import { AiOutlineUser } from "react-icons/ai";

export const LOGIN_ROUTE = "/login";
export const SIGNIN_ROUTE = "/signin";
export const MAIN_ROUTE = "/main";
export const NOTES_ROUTE = "notes";
export const SEARCH_ROUTE = "/search";
export const ARTICLES_ROUTE = "/article";
export const PROFILE_ROUTE = "/profile";
export const SOVIETS_ROUTE = "/soviets";
export const TESTS_ROUTE = "/tests";

export const NAVBAR_PARAMS = [
  { title: "Главный", link: MAIN_ROUTE, Icon: CgHome },
  { title: "Записи", link: NOTES_ROUTE, Icon: BsCalendarWeek },
  { title: "Поиск", link: SEARCH_ROUTE, Icon: BiSearch },
  { title: "Статьи", link: ARTICLES_ROUTE, Icon: RiArticleLine },
  { title: "Профиль", link: PROFILE_ROUTE, Icon: AiOutlineUser },
];
