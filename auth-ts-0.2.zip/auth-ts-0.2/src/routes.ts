import { Component } from "react";
import { ArticlesPage } from "./components/ArticlesPage";
import { LoginPage } from "./components/LoginPage";
import { MainPage } from "./components/MainPage";
import { NotesPage } from "./components/NotesPage";
import { ProfilePage } from "./components/ProfilePage";
import { SearchsPage } from "./components/SearchPage";
import { SigninPage } from "./components/SigninPage";
import { SovietsPage } from "./components/SovietsPage";
import { TestsPage } from "./components/TestsPage";
import {
  LOGIN_ROUTE,
  SIGNIN_ROUTE,
  MAIN_ROUTE,
  NOTES_ROUTE,
  SEARCH_ROUTE,
  ARTICLES_ROUTE,
  PROFILE_ROUTE,
  SOVIETS_ROUTE,
  TESTS_ROUTE,
} from "./utils/consts";

export const publicRoutes = [
  { path: LOGIN_ROUTE, Component: LoginPage },
  { path: SIGNIN_ROUTE, Component: SigninPage },
];

export const privateRoutes = [
  { path: MAIN_ROUTE, Component: MainPage },
  { path: NOTES_ROUTE, Component: NotesPage },
  { path: SEARCH_ROUTE, Component: SearchsPage },
  { path: ARTICLES_ROUTE, Component: ArticlesPage },
  { path: PROFILE_ROUTE, Component: ProfilePage },
  { path: LOGIN_ROUTE, Component: LoginPage },
  { path: SIGNIN_ROUTE, Component: SigninPage },
  { path: SOVIETS_ROUTE, Component: SovietsPage },
  { path: TESTS_ROUTE, Component: TestsPage },
];
